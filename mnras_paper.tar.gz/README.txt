This is a support code and data for MNRAS paper. 
